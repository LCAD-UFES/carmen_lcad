#ifndef _TRACKER_USER_FUNCTIONS_H
#define _TRACKER_USER_FUNCTIONS_H

// Includes
#include <mae.h>
#include <filter.h>
#include "../tracker.h"

//CARMEN includes
#include <carmen/carmen.h>
#include <carmen/tracker_messages.h>
#include <carmen/tracker_interface.h>

#ifdef __cplusplus
extern "C" {
#endif

// External defined filtered pattern - for error data visualization - same in filter module
extern float	*gaussian_filtered_training_pattern;
extern float	gaussian_filtered_training_pattern_sum;

// Required Prototypes
int		update_input_filters();
void	update_input_layer_neurons_and_image(INPUT_DESC*);
void 	update_input_layer_neurons_and_image_light(INPUT_DESC*);
void	set_input_layer_translation(INPUT_DESC *,int,int);

void	tracker_train(void);
void	tracker_saccade(INPUT_DESC *, int, float, int *, int *);
float	tracker_confidence(NEURON_LAYER *, int);
float	tracker_scale(NEURON_LAYER *);

#ifdef __cplusplus
}
#endif

#endif

