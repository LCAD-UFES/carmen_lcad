#include <carmen/carmen_graphics.h>	//must come first
#include <carmen/tracker_interface.h>
//#include <carmen/neural_global_localizer_interface.h>
#include <carmen/stereo_util.h>
#include <assert.h>
#include <cairo.h>	//libcairo
#include <gtk/gtk.h>	//gtk interface

#include <carmen/tracker_messages.h>
#include "tracker_handlers.h"
/*
static carmen_tracker_output_message message_output;

void
read_parameters(int argc, char** argv)
{
	argc = argc;
	argv = argv;
}

void
publish_tracker_output_message()
{
	IPC_RETURN_TYPE err;
	err = IPC_publishData(CARMEN_TRACKER_OUTPUT_MESSAGE_NAME, &message_output);
	carmen_test_ipc_exit(err, "Could not publish", CARMEN_TRACKER_OUTPUT_MESSAGE_NAME);
}

void
carmen_tracker_subscribe_messages()
{
	//carmen_tracker_subscribe_train(NULL, (carmen_handler_t)tracker_train_message_handler, CARMEN_SUBSCRIBE_LATEST);

	//carmen_tracker_subscribe_test(NULL, (carmen_handler_t)tracker_test_message_handler, CARMEN_SUBSCRIBE_ALL);
}

void
carmen_tracker_define_messages()
{
	carmen_tracker_define_message_output();
}
*/

int
main(int argc, char **argv)
{
 // carmen_ipc_initialize(argc, argv);

  carmen_param_check_version(argv[0]);

  //read_parameters(argc, argv);

// carmen_tracker_define_messages();

  /*carmen_tracker_subscribe_messages();
*/
 // carmen_ipc_dispatch();

  return (0);
}
