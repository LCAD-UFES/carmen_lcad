// -----------------------------------------------------------------------------
//! \file MathUtils.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __MATH_UTILS_H
#define __MATH_UTILS_H

#include <cmath>
#include <cassert>
#include <iostream>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/vector_proxy.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <boost/numeric/ublas/triangular.hpp>
#include <boost/numeric/ublas/vector_expression.hpp>
#include <boost/numeric/ublas/matrix_expression.hpp>
#include <boost/numeric/ublas/lu.hpp>
#include <boost/numeric/ublas/io.hpp>

#ifdef __MKL
	//#include "mkl_cblas.h"
//	#include "mkl.h"
	#include "mkl_boost_ublas_matrix_prod.hpp"
#endif

#define Array1D boost::numeric::ublas::vector
#define Array2D boost::numeric::ublas::matrix

// -----------------------------------------------------------------------------
//! \brief The %MathUtils namespace defines mathematical utilities functions.
//! It implements methods to perform mathematical operations on 1D and 2D arrays.
// -----------------------------------------------------------------------------
namespace MathUtils
{
	// -----------------------------------------------------------------------------
	//! \brief Computes the inverse of a matrix.
	//!
	//! To compute the inverse, first we find the LU decomposition of the matrix. Then, the inverse
	//! may be obtained by the linear equation:
	//! @f[L U A^{-1} = I@f]
	//! where @f$L@f$ and @f$U@f$ are the lower triangular and upper matrixes of the LU
	//! decomposition, respectively, @f$A^{-1}@f$ is the inverse, and @f$I@f$ is the identity matrix.
	//!
	//! @param[in] a Matrix.
	//! @param[in] pLu Pointer to the LU decomposition of the matrix; if null or not specified, the
	//! method will calculate the LU decomposition.
	//!
	//! @return The inverse matrix, or an empty matrix if the matrix is singular.
	// -----------------------------------------------------------------------------
	template<class T>
	Array2D<T> inv (const Array2D<T> &a)
	{
		using namespace boost::numeric::ublas;
		
		matrix<T> inverse(a);
		
		// Create a working copy of the input
		matrix<T> A(a);
		
		// Create a permutation matrix for the LU-factorization
		permutation_matrix<std::size_t> pm(A.size1());
		
		// Perform LU-factorization
		if(lu_factorize(A,pm) == 0)
		{
			// Create identity matrix of "inverse"
			inverse.assign(identity_matrix<T>(A.size1()));
			
			// Backsubstitute to get the inverse
			lu_substitute(A, pm, inverse);
		}
		
		return inverse;
	}

	// -----------------------------------------------------------------------------
	//! \brief Computes the determinant of a matrix.
	//!
	//! To compute the determinant, first we find the LU decomposition of the matrix. Then, the determinant may be computed by:
	//! @f[\det(A) = \det(L)\det(U)@f]
	//! where @f$L@f$ and @f$U@f$ are the lower triangular and upper matrixes of the LU decomposition.
	//!
	//! @param[in] a A matrix.
	//!
	//! @return The determinant of the matrix.
	// -----------------------------------------------------------------------------
	template <class T>
	T det (const Array2D<T> &a)
	{
		using namespace boost::numeric::ublas;
		
		// Create a working copy of the input
		matrix<T> A(a);
		
		// Create a permutation matrix for the LU-factorization
		permutation_matrix<std::size_t> pm(A.size1());
		
		// Perform LU-factorization
		if(lu_factorize(A, pm))
		{
			return T(0);
		}
		
		// Multiply by elements on diagonal
		T det = T(1);
		for(std::size_t i = 0; i < A.size1(); i++)
			det *= A(i,i);
		
		// Get the determinant sign
		T det_sign= T(1);
		std::size_t size = pm.size();
		for(std::size_t i = 0; i < size; ++i)
		{
			if (i != pm(i))
			{
				det_sign *= T(-1); // swap_rows would swap a pair of rows here, so we change sign
			}
		}
		det = det * det_sign;
		
		return det;
	}

	// -----------------------------------------------------------------------------
    //! \brief Computes the Cholesky decomposition of a matrix.
    //!
    //! @param[in] A A matrix.
    //!
    //! @return The Cholesky decomposition L such that L*~L=A.
	// -----------------------------------------------------------------------------
	template <class Real = double>
	Array2D<Real> chol (const Array2D<Real> & A)
	{
		using namespace boost::numeric::ublas;
		
		assert(A.size1() == A.size2());
		
		const size_t n = A.size1();
		
		Array2D<Real> L(n,n,0.0);
		
		for (size_t k = 0 ; k < n; k++)
		{
		
			Real qL_kk = A(k,k) - inner_prod(project(row(L,k),range(0,k)),project(row(L,k),range(0,k)));
			
			if (qL_kk <= Real(0))
			{
				return zero_matrix<Real>(n,n);
			}
			else
			{
				Real L_kk = sqrt(qL_kk);
				
				L(k,k) = L_kk;
				
				matrix_column<Array2D<Real>> cLk(L,k);
				project(cLk,range(k+1,n)) = (project(column(A,k),range(k+1,n)) -
						prod(project(L,range(k+1,n),range(0,k)),project(row(L,k),range(0,k))))/L_kk;
			}
		}
		
		return L;
	}

//	template <class T>
//	ostream& operator<< (ostream& os, const Array2D<T> &a)
//	{
//		int M = a.dim1();
//		int N = a.dim2();
//
//		for (int i = 0; i < M; i++)
//		{
//			for (int j = 0; j < N; j++)
//			{
//				os << a[i][j] << " ";
//			}
//
//			os << endl;
//		}
//
//		return os;
//	}

//	template <class T>
//	ostream& operator<< (ostream& os, const Array1D<T> &a)
//	{
//		int M = a.dim1();
//
//		for (int i = 0; i < M; i++)
//			os << a[i] << endl;
//
//		return os;
//	}

	template<class T>
	Array2D<T> pinvl (const Array2D<T> &a)
	{
		using namespace boost::numeric::ublas;
		
		matrix<T> pseudo_inverse(a.size2(),a.size1());
		
		matrix<T> taa(a.size2(),a.size2());
		
		taa.assign(prod(trans(a),a));
		
		pseudo_inverse.assign(prod(inv(taa),trans(a)));
		
		return pseudo_inverse;
	}
	template<class T>
	Array2D<T> pinvr (const Array2D<T> &a)
	{
		using namespace boost::numeric::ublas;
		
		matrix<T> pseudo_inverse(a.size2(),a.size1());
		
		matrix<T> ata(a.size1(),a.size1());
		
		ata.assign(prod(a,trans(a)));
		
		pseudo_inverse.assign(prod(trans(a),inv(ata)));
		
		return pseudo_inverse;
	}

	template<class M>
	struct matrix_tr:
	public boost::numeric::ublas::matrix_scalar_real_unary_functor<M>
	{
		typedef typename boost::numeric::ublas::matrix_scalar_real_unary_functor<M>::value_type value_type;
		typedef typename boost::numeric::ublas::matrix_scalar_real_unary_functor<M>::real_type real_type;
		typedef typename boost::numeric::ublas::matrix_scalar_real_unary_functor<M>::result_type result_type;
		
		template<class E>
		static BOOST_UBLAS_INLINE
		result_type apply (const boost::numeric::ublas::matrix_expression<E> &e)
		{
			using namespace boost::numeric::ublas;
			assert(e ().size1() == e ().size2());
			real_type t = real_type (0);
			typedef typename E::size_type matrix_size_type;
			matrix_size_type size2 (e ().size2 ());
			for (matrix_size_type i = 0; i < size2; ++ i)
			{
					real_type v (e () (i, i));
					t += v;
			}
			return t;
		}
	};
	
	// -----------------------------------------------------------------------------
	//! \brief Calculate the transpose of a matrix.
	//!
	//! \param[in] e Expression.
	//!
	//! \return The transpose of a matrix.
	// -----------------------------------------------------------------------------
	template<class E>
	BOOST_UBLAS_INLINE
	typename boost::numeric::ublas::matrix_scalar_unary_traits<E, matrix_tr<E> >::result_type
	tr (const boost::numeric::ublas::matrix_expression<E> & e)
	{
		using namespace boost::numeric::ublas;
		typedef typename matrix_scalar_unary_traits<E, matrix_tr<E> >::expression_type expression_type;
		return expression_type(e());
	}

//	template<class T>
//	T tr (const Array2D<T> &A)
//	{
//		using namespace boost::numeric::ublas;
//
//		assert(A.size1() == A.size2());
//
//		T value = T(0);
//
//		const size_t n = A.size1();
//
//		for (size_t k = 0 ; k < n; k++)
//		{
//			value += A(k,k);
//		}
//
//		return value;
//	}

	// -----------------------------------------------------------------------------
	//! \brief Create an identity matrix.
	//!
	//! \param[in] n The matrix size.
	//!
	//! \return The identity matrix with the appropriate dimensions.
	// -----------------------------------------------------------------------------
	template <class Real = double>
	BOOST_UBLAS_INLINE
	Array2D<Real> eye (size_t n)
	{
		using namespace boost::numeric::ublas;
		
		return identity_matrix<Real> (n);
	}
	
	// -----------------------------------------------------------------------------
	//! \brief Project point p onto line segment from A to B.
	//!
	//! \param[in] A 1st line segment vertex.
	//! \param[in] B 2nd line segment vertex.
	//! \param[in] p A point.
	//!
	//! \return The closest point q to p on the line segment from A to B.
	// -----------------------------------------------------------------------------
	template<class T>
	Array1D<T> proj (const Array1D<T> &A, const Array1D<T> &B, const Array1D<T> &p)
	{
		using namespace boost::numeric::ublas;
		
		Array1D<T> q(p.size());
		
		// Vector from A to B
		Array1D<T> AB(B-A);
		
		// Squared distance from A to B
		T AB_squared = inner_prod(AB,AB);
		
		if(AB_squared == 0.0)
		{
			// A and B are the same point
			q.assign(A);
		}
		else
		{
			//  Vector from A to p
			Array1D<T> Ap(p-A);
			
			T t = inner_prod(Ap,AB)/AB_squared;
			if (t < 0.0)
			{
				// "Before" A on the line, just return A
				q.assign(A);
			}
			else if (t > 1.0)
			{
				// "After" B on the line, just return B
				q.assign(B);
			}
			else
			{
				// Projection lines "inbetween" A and B on the line
				q.assign(A + t * AB);
			}
		}
		
		return q;
	}
}

#endif
