// -----------------------------------------------------------------------------
//! \file MiscUtils.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __MISC_UTILS_H
#define __MISC_UTILS_H

#include <cmath>
#include <iostream>
#include <sstream>
#include <dirent.h>
#include <vector>
#include <opencv2/opencv.hpp>
#include <boost/foreach.hpp>
#include "Point2D.h"

#define foreach BOOST_FOREACH

// -----------------------------------------------------------------------------
//! \brief The %MiscUtils namespace defines miscellaneous utilities functions.
// -----------------------------------------------------------------------------
namespace MiscUtils
{
	void RandNorm2D(float sigma, float *x, float *y);
	
	float RandNorm(float m, float s);
	
	void Rand2D(float radius, float *x, float *y);
	
	void Rand2D(float max_x, float max_y, float *x, float *y);
	
	std::vector<std::string> DirectoryLister (std::string strPath, bool bFiles, bool bDirectories, bool bHidden);
	
	bool Intersection(Point2D A, Point2D B, Point2D C, Point2D D);
	
	double IntersectionAngle(Point2D A, Point2D B, Point2D C, Point2D D);
	
	bool Intersection2(Point2D A, Point2D B, Point2D C, Point2D D, double *dblAngle = NULL);
	
	double AngleDiff(double dblAlpha, double dblBeta);
	
	double Deg2Rad(double dblAngle);
	
	double Rad2Deg(double dblAngle);
	
	cv::Scalar PickColor(size_t index);
	
	template <class T>
	std::string toStr(T a)
	{
		std::stringstream ss;
		ss << a;
		return ss.str();
	}
}

#endif
