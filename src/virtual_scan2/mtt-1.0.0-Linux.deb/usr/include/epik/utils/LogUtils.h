// -----------------------------------------------------------------------------
//! \file LogUtils.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __LOG_UTILS_H
#define __LOG_UTILS_H

#include <iostream>

// -----------------------------------------------------------------------------
//! \brief Logging functions.
// -----------------------------------------------------------------------------
namespace LogUtils
{
	void InitializeLogger(bool bVerbose, bool bDebug);
	
	void LogMsg(const std::string &strMsg);
	
	void LogError(const std::string &strMsg);
	
	void LogWarning(const std::string &strMsg);
	
	void LogDebug(const std::string &strMsg);
};

#endif
