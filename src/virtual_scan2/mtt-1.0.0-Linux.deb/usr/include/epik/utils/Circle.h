// -----------------------------------------------------------------------------
//! \file Circle.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 05/12/2019
// -----------------------------------------------------------------------------

#ifndef __CIRCLE_H
#define __CIRCLE_H

#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "Point2D.h"

// -----------------------------------------------------------------------------
//! \brief This class defines a circle.
// -----------------------------------------------------------------------------
class Circle
{
	public:
		Circle();
		
		Circle(Point2D center, double radius);
		
		Circle(const Circle &circle);
		
		virtual ~Circle();
		
		bool IsInside(Point2D point);
		
		void Draw(cv::Mat image, double sx, double sy, double ox, double oy, cv::Scalar color, bool filled = false);
				
		/*! Circle center.
		 */
		Point2D center;
		
		/*! Circle radius.
		 */
		double radius;
};

#endif
