// -----------------------------------------------------------------------------
//! \file TimeUtils.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __TIME_UTILS_H
#define __TIME_UTILS_H

#include <iostream>
#include <ctime>

// -----------------------------------------------------------------------------
//! \brief Name space with time functions.
// -----------------------------------------------------------------------------
namespace TimeUtils
{
	typedef struct tm TimeInfo;
	
	void GetLocalTime(TimeInfo *t);
	
	void GetGMTime(TimeInfo *t);
	
	std::string TimeToString(TimeInfo t);
	
	std::string LocalTimeToString(double localtime);
	
	double StringToLocalTime(std::string strLocaltime);
	
	double GetCurrentTime();
};

#endif
