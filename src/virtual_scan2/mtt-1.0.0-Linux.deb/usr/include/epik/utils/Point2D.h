// -----------------------------------------------------------------------------
//! \file Point2D.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __POINT_2D_H
#define __POINT_2D_H

// -----------------------------------------------------------------------------
//! \brief This class defines a 2D point.
// -----------------------------------------------------------------------------
class Point2D
{
	public:
		Point2D();
		
		Point2D(double x, double y);
		
		Point2D(const Point2D &point);
		
		virtual ~Point2D();
		
		/*! X coordinate.
		 */
		double x;
		
		/*! Y coordinate.
		 */
		double y;
};

#endif
