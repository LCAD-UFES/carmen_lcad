// -----------------------------------------------------------------------------
//! \file StatUtils.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __STAT_UTILS_H
#define __STAT_UTILS_H

#include <boost/random/variate_generator.hpp>
#include <boost/random/normal_distribution.hpp>
#include <boost/random/uniform_real.hpp>
#include <boost/random/poisson_distribution.hpp>
#include <boost/random/mersenne_twister.hpp>
#include "MathUtils.h"

using namespace MathUtils;

// -----------------------------------------------------------------------------
//! \brief The %StatUtils namespace defines statistical utilities functions and types.
// -----------------------------------------------------------------------------
namespace StatUtils
{
    // -----------------------------------------------------------------------------
    //! \brief Calculate the normalized statistical distance.
    //!
    //! \param[in] v Residual vector (innovation).
    //! \param[in] S Residual covariance matrix.
    //!
    //! \return The normalized statistical distance.
    // -----------------------------------------------------------------------------
	template <class Real = double>
	Real NormDistance(Array1D<Real> v, Array2D<Real> S)
	{
		using namespace boost::numeric::ublas;
		
		Array2D<Real> invS = inv(S);
		Array1D<Real> transv = trans(v);
		Array1D<Real> invSv = prod(invS,v);
		
		return inner_prod(transv,invSv);
	}
	
	/** Underlying integer random generator type.
	 */
	typedef boost::mt19937 Generator;
	
	/** Normal distribution type.
	 */
	typedef boost::normal_distribution<> NormalDistribution;
	
	/** Uniform distribution type.
	 */
	typedef boost::uniform_real<> UniformDistribution;
	
	/** Poisson distribution type.
	 */
	typedef boost::poisson_distribution<> PoissonDistribution;
	
	/** Normal distribution sample generator type.
	 */
	typedef boost::variate_generator<Generator, NormalDistribution> Normal;
	
	/** Uniform distribution sample generator type.
	 */
	typedef boost::variate_generator<Generator, UniformDistribution> Uniform;
	
	/** Poisson distribution sample generator type.
	 */
	typedef boost::variate_generator<Generator, PoissonDistribution> Poisson;
	
	/** Class to sample from a multivariate normal distribution
	 */
	template <class Real = double>
	class MultivariateNormal
	{
		public:
			// -----------------------------------------------------------------------------
			//! \brief Default constructor.
			//!
			//! \param[in] mean Mean vector.
			//! \param[in] sigma Covariance matrix.
			// -----------------------------------------------------------------------------
			MultivariateNormal(Array1D<Real> &mean, Array2D<Real> &sigma) :
				_mean(mean),
				_sigma(sigma),
				_normal(Generator(), NormalDistribution(0,1))
			{
				_chol = chol(_sigma);
			}
			
			// -----------------------------------------------------------------------------
			//! \brief Default constructor.
			//!
			//! \param[in] mean Mean vector.
			//! \param[in] sigma Covariance matrix.
			// -----------------------------------------------------------------------------
//			MultivariateNormal(Real mean, Array2D<Real> &sigma) :
//				_mean(sigma.size1(), mean),
//				_sigma(sigma),
//				_normal(Generator(), NormalDistribution(0,1))
//			{
//				_chol = chol(_sigma);
//			}
			
			// -----------------------------------------------------------------------------
			//! \brief Default constructor.
			//!
			//! \param[in] mean Mean vector.
			//! \param[in] sigma Covariance matrix.
			// -----------------------------------------------------------------------------
			MultivariateNormal(Real mean, Array2D<Real> sigma) :
				_mean(sigma.size1(), mean),
				_sigma(sigma),
				_normal(Generator(), NormalDistribution(0,1))
			{
				_chol = chol(_sigma);
			}
			
			// -----------------------------------------------------------------------------
			//! \brief Get the mean.
			//!
			//! \return The mean vector.
			// -----------------------------------------------------------------------------
			Array1D<Real> mean() const { return _mean; }
			
			// -----------------------------------------------------------------------------
			//! \brief Get the sigma.
			//!
			//! \return The covariance matrix.
			// -----------------------------------------------------------------------------
			Array2D<Real> sigma() const { return _sigma; }
			
			// -----------------------------------------------------------------------------
			//! \brief Draw a sample from the normal distribution.
			//!
			//! \return The sampled vector.
			// -----------------------------------------------------------------------------
			Array1D<Real> operator()()
			{
				using namespace boost::numeric::ublas;
				
				Array1D<Real> z(_mean.size());
				
//				clog << "_chol = " << _chol << endl;
				
				for(size_t i = 0; i < z.size(); i++)
					z[i] = _normal();
				
//				clog << "_mean = " << _mean << endl;
//				clog << "z = " << z << endl;
				
				return (_mean + prod(_chol,z));
			}
			
			// -----------------------------------------------------------------------------
			//! \brief Set the seed.
			//!
			//! \param[in] The new seed.
			// -----------------------------------------------------------------------------
			void seed(int seed)
			{
				_normal.engine().seed(seed);
				_normal.distribution().reset();
			}
		
		private:
			/*! Mean vector.
			 */
			Array1D<Real> _mean;
			
			/*! Covariance matrix.
			 */
			Array2D<Real> _sigma;
			
			/*! Normal distribution.
			 */
			Normal _normal;
			
			/*! Cholesky decomposition of the covariance matrix.
			 */
			Array2D<Real> _chol;
	};
}

#endif
