// -----------------------------------------------------------------------------
//! \file Box2D.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __BOX2D_H
#define __BOX2D_H

#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "Point2D.h"

// -----------------------------------------------------------------------------
//! \brief This class defines a 2D box (rectangle).
// -----------------------------------------------------------------------------
class Box2D
{
	public:
		Box2D();
		
		Box2D(Point2D center, Point2D size, int category = 0, double orientation = .0);
		
		Box2D(const Box2D &box);
		
		virtual ~Box2D();
		
		bool IsInside(Point2D point);
		
		void Draw(cv::Mat image, double sx, double sy, double ox, double oy, cv::Scalar color, bool filled = false);
		
		void Draw(cv::Mat image, double sx, double sy, double ox, double oy, bool filled = false);
		
		/*! Box center.
		 */
		Point2D center;
		
		/*! Box size.
		 */
		Point2D size;
		
		/*! Box category.
		 */
		int category;
		
		/*! Box orientation.
		 */
		double orientation;
};

#endif
