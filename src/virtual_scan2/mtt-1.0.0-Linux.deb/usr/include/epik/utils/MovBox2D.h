// -----------------------------------------------------------------------------
//! \file MovBox2D.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __MOV_BOX_2D_H
#define __MOV_BOX_2D_H

#include "Box2D.h"

// -----------------------------------------------------------------------------
//! \brief This class defines a moving 2D box.
// -----------------------------------------------------------------------------
class MovBox2D : public Box2D
{
	public:
		MovBox2D();
		
		MovBox2D(const MovBox2D &box);
		
		virtual ~MovBox2D();
		
		void Draw(cv::Mat image, double sx, double sy, double ox, double oy, cv::Scalar color, bool moving = true);
		
		void Draw(cv::Mat image, double sx, double sy, double ox, double oy, bool moving = true);
		
		Point2D vel;
};

#endif
