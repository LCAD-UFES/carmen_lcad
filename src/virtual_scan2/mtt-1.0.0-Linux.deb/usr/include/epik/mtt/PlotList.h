// -----------------------------------------------------------------------------
//! \file PlotList.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __PLOTLIST_H
#define __PLOTLIST_H

#include "Plot.h"
#include <vector>

// -----------------------------------------------------------------------------
//! \brief Plot list.
// -----------------------------------------------------------------------------
class PlotList : public std::vector<Plot>
{
	public:
		PlotList();
		
		PlotList(size_t capacity);
		
		virtual ~PlotList();
		
		void Print();
		
		/*! Sensor index.
		 */
		size_t m_sensorIdx;
};

#endif
