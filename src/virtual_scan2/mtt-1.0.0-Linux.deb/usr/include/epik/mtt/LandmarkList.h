// -----------------------------------------------------------------------------
//! \file LandmarkList.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 24/11/2019
// -----------------------------------------------------------------------------

#ifndef __LANDMARK_LIST_H
#define __LANDMARK_LIST_H

#include "Landmark.h"
#include <vector>

// -----------------------------------------------------------------------------
//! \brief This class implements a list of static landmarks.
// -----------------------------------------------------------------------------
class LandmarkList : public std::vector<Landmark>
{
	public:
		LandmarkList();
		
		LandmarkList(size_t capacity);
		
		virtual ~LandmarkList();
		
		void Print();
};

#endif
