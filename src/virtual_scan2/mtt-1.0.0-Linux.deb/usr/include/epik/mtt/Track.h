// -----------------------------------------------------------------------------
//! \file Track.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __TRACK_H
#define __TRACK_H

#include "MovBox2D.h"
#include "TrackerConfig.h"

// -----------------------------------------------------------------------------
//! \brief This class defines a track.
// -----------------------------------------------------------------------------
class Track
{
	public:
		Track();
		
		Track(const Track &track);
		
		virtual ~Track();
		
		void Draw(cv::Mat image, double sx, double sy, double ox, double oy);
		
		bool operator<(const Track &track);
		
		/*! Track unique id.
		 */
		int id;
		
#ifdef USE_IMM_FILTER
		/*! Moving indicator flag.
		 */
		bool moving;
#endif
		/*! Track state.
		 */
		MovBox2D state;
		
		/*! Time stamp.
		 */
		double timeStamp;
};

#endif
