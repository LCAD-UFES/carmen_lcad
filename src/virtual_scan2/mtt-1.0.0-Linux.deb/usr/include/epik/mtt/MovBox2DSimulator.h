// -----------------------------------------------------------------------------
//! \file MovBox2DSimulator.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __MOV_BOX_2D_SIMULATOR_H
#define __MOV_BOX_2D_SIMULATOR_H

#include "Simulator.h"
#include "DynamicModel.h"
#include "Circle.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a moving 2D box simulator.
// -----------------------------------------------------------------------------
class MovBox2DSimulator : public Simulator
{
	public:
		MovBox2DSimulator();
		
		virtual ~MovBox2DSimulator();
		
		void Initialize();
		
		void Process(double currentTime);
		
		void Finalize();
		
		void Rewind();
		
		void Draw();
		
	private:
		/*! Number of moving targets.
		 */
		size_t m_nNumberOfTargets;
		
		/*! Maximum target XY velocity.
		 */
		double m_maxTargetXYVelocity;
		
		/*! Maximum target size along the X axis.
		 */
		double m_maxTargetXSize;
		
		/*! Maximum target size along the X axis.
		 */
		double m_maxTargetYSize;
		
		/*! Number of simulated landmarks
		 */
		size_t m_nNumberOfLandmarks;
		
		/*! Maximum landmark size along the X axis.
		 */
		double m_maxLandmarkXSize;
		
		/*! Maximum landmark size along the Y axis.
		 */
		double m_maxLandmarkYSize;
		
		/*! Number of simulated categories
		 */
		size_t m_nNumberOfCategories;
		
		/*! Previous time stamp.
		 */
		double m_previousTime;
		
		/*! Pseudo-radom number generator seed.
		 */
		int m_nSeed;
		
		/*! Dynamic model to simulate moving targets.
		 */
		DynamicModel *m_pDynamicModel;
		
		/*! Surveillance region bounds.
		 */
		Box2D *m_pSurveillanceRegion;
		
		/*! Sensor coverage.
		 */
		Circle *m_pSensorCoverage;
};

#endif
