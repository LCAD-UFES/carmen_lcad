// -----------------------------------------------------------------------------
//! \file MovBox2DTracker.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __MOV_BOX_2D_TRACKER_H
#define __MOV_BOX_2D_TRACKER_H

#include <vector>
#include <string>
#include "Tracker.h"
#include "Pipeline.h"
#include "AlignedInputList.h"
#include "InnerTrackList.h"
#include "Circle.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a moving 2D boxes tracker.
// -----------------------------------------------------------------------------
class MovBox2DTracker : public Tracker
{
	public:
		MovBox2DTracker();
		
		virtual ~MovBox2DTracker();
		
		void Initialize();
		
		void Process(double currentTime);
		
		void Finalize();
		
		void Rewind();
		
		void Draw();
		
		InnerTrackList* GetMasterTrackList();
		
	private:
		/*! Tracking pipeline.
		 */
		Pipeline m_trackingPipeline;
		
		/*! Surveillance region bounds.
		 */
		Box2D *m_pSurveillanceRegion;
		
		/*! Sensor coverage.
		 */
		Circle *m_pSensorCoverage;
};

#endif
