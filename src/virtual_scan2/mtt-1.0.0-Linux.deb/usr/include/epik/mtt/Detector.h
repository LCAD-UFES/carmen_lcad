// -----------------------------------------------------------------------------
//! \file Detector.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __DETECTOR_H
#define __DETECTOR_H

#include "PipelineModule.h"
#include "TargetList.h"
#include "LandmarkList.h"
#include "PlotList.h"
#include "MTTConfig.h"

using namespace MTTConfig;

// -----------------------------------------------------------------------------
//! \brief This class implements a generic detector.
// -----------------------------------------------------------------------------
class Detector : public PipelineModule
{
	public:
		Detector(std::string name);
		
		virtual ~Detector();
		
		virtual void Initialize();
		
		virtual void Finalize();
		
		virtual void Rewind();
		
	protected:
		/*! List of input targets.
		 */
		TargetList *m_pTargetList;
		
		/*! List of input landmarks.
		 */
		LandmarkList *m_pLandmarkList;
		
		/*! List of output plots/detections
		 */
		PlotList *m_pPlotList;
};

#endif
