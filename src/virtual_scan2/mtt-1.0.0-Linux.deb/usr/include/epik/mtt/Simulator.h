// -----------------------------------------------------------------------------
//! \file Simulator.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __SIMULATOR_H
#define __SIMULATOR_H

#include "PipelineModule.h"
#include "TargetList.h"
#include "LandmarkList.h"
#include "MTTConfig.h"

using namespace MTTConfig;

// -----------------------------------------------------------------------------
//! \brief This class implements a generic scenario simulator.
// -----------------------------------------------------------------------------
class Simulator : public PipelineModule
{
	public:
		Simulator(std::string name);
		
		virtual ~Simulator();
		
		virtual void Initialize();
		
		virtual void Finalize();
		
		virtual void Rewind();
		
	protected:
		/*! Target list.
		 */
		TargetList *m_pTargetList;
		
		/*! Landmark list.
		 */
		LandmarkList *m_pLandmarkList;
};

#endif
