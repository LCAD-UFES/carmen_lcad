// -----------------------------------------------------------------------------
//! \file Landmark.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 24/11/2019
// -----------------------------------------------------------------------------

#ifndef __LANDMARK_H
#define __LANDMARK_H

#include "Box2D.h"

// -----------------------------------------------------------------------------
//! \brief This class defines a static landmark (ground truth).
// -----------------------------------------------------------------------------
class Landmark
{
	public:
		Landmark();
		
		Landmark(const Landmark &target);
		
		virtual ~Landmark();
		
		void Draw(cv::Mat image, double sx, double sy, double ox, double oy);
		
		/*! Landmark unique id.
		 */
		int id;
		
		/*! Landmark state.
		 */
		Box2D state;
		
		/*! Time stamp.
		 */
		double timeStamp;
};

#endif
