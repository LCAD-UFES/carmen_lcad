// -----------------------------------------------------------------------------
//! \file MTTConfig.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __MTT_CONFIG_H
#define __MTT_CONFIG_H

// the configured options and settings for LIBMTT
#define LIBMTT_VERSION_MAJOR 1
#define LIBMTT_VERSION_MINOR 0
#define LIBMTT_VERSION_PATCH 0
#define LIBMTT_VERSION "1.0.0"

namespace MTTConfig
{
// Invalid IDs/category
#define NIL -1

// Internal bounds to limit processing burden
const int MAX_NUMBER_OF_TARGETS = 200;
const int MAX_NUMBER_OF_LANDMARKS = 100;
const int MAX_NUMBER_OF_INPUTS = 150;
const int MAX_NUMBER_OF_TRACKS = 200;

}

#endif
