// -----------------------------------------------------------------------------
//! \file Target.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __TARGET_H
#define __TARGET_H

#include "MovBox2D.h"

// -----------------------------------------------------------------------------
//! \brief This class defines a target (ground truth).
// -----------------------------------------------------------------------------
class Target
{
	public:
		Target();
		
		Target(const Target &target);
		
		virtual ~Target();
		
		void Draw(cv::Mat image, double sx, double sy, double ox, double oy);
		
		/*! Target unique id.
		 */
		int id;
		
		/*! Target state.
		 */
		MovBox2D state;
		
		/*! Time stamp.
		 */
		double timeStamp;
};

#endif
