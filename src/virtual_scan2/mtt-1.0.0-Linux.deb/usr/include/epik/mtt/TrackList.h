// -----------------------------------------------------------------------------
//! \file TrackList.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __TRACK_LIST_H
#define __TRACK_LIST_H

#include "Track.h"
#include <vector>

// -----------------------------------------------------------------------------
//! \brief This class implements a track list.
// -----------------------------------------------------------------------------
class TrackList : public std::vector<Track>
{
	public:
		TrackList();
		
		TrackList(size_t capacity);
		
		virtual ~TrackList();
		
		Track *GetTrackPointerByTrackId(int nTrackId);
		
		TrackList *Clone();
		
		void Print();
};

#endif
