// -----------------------------------------------------------------------------
//! \file TargetList.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __TARGET_LIST_H
#define __TARGET_LIST_H

#include "Target.h"
#include <vector>

// -----------------------------------------------------------------------------
//! \brief This class implements a list of targets.
// -----------------------------------------------------------------------------
class TargetList : public std::vector<Target>
{
	public:
		TargetList();
		
		TargetList(size_t capacity);
		
		virtual ~TargetList();
		
		void Print();
};

#endif
