// -----------------------------------------------------------------------------
//! \file Tracker.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __TRACKER_H
#define __TRACKER_H

#include "PipelineModule.h"
#include "PlotList.h"
#include "TrackList.h"
#include "MTTConfig.h"

using namespace MTTConfig;

// -----------------------------------------------------------------------------
//! \brief This class implements a generic tracker.
// -----------------------------------------------------------------------------
class Tracker : public PipelineModule
{
	public:
		Tracker(std::string name);
		
		virtual ~Tracker();
		
		virtual void Initialize();
		
		virtual void Finalize();
		
		virtual void Rewind();
		
	protected:
		/*! Plot list.
		 */
		PlotList *m_pPlotList;
		
		/*! Output track list.
		 */
		TrackList *m_pOutputTrackList;
};

#endif
