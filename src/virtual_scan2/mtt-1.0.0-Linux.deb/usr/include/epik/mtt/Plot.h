// -----------------------------------------------------------------------------
//! \file Plot.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __PLOT_H
#define __PLOT_H

#include "MovBox2D.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a plot.
// -----------------------------------------------------------------------------
class Plot
{
	public:
		Plot();
		
		Plot(const Plot &plot);
		
		virtual ~Plot();
		
		void Draw(cv::Mat image, double sx, double sy, double ox, double oy);
		
		/*! Measurement data.
		 */
		MovBox2D measurement;
		
		/*! Time stamp.
		 */
		double timeStamp;
};

#endif
