// -----------------------------------------------------------------------------
//! \file MovBox2DDetector.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __MOV_BOX_2D_DETECTOR_H
#define __MOV_BOX_2D_DETECTOR_H

#include "Detector.h"
#include "ObservationModel.h"
#include "Circle.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a moving 2D box detector.
// -----------------------------------------------------------------------------
class MovBox2DDetector : public Detector
{
	public:
		MovBox2DDetector();
		
		virtual ~MovBox2DDetector();
		
		void Initialize();
		
		void Process(double currentTime);
		
		void Finalize();
		
		void Rewind();
		
		void Draw();
		
	private:
		/*! Probability of detection.
		 */
		double m_probabilityOfDetection;
		
		/*! False alarm rate.
		 */
		double m_falseAlarmRate;
		
		/*! Maximum target size along X axis.
		 */
		double m_maxTargetXSize;
		
		/*! Maximum target size along Y axis.
		 */
		double m_maxTargetYSize;
		
		/*! Maximum landmark size along X axis.
		 */
		double m_maxLandmarkXSize;
		
		/*! Maximum landmark size along Y axis.
		 */
		double m_maxLandmarkYSize;
		
		/*! Number of categories.
		 */
		size_t m_nNumberOfCategories;
		
		/*! Probability of detecting the truth category.
		 */
		double m_probabilityOfDetectingTruthCategory;
		
		/*! Previous time stamp.
		 */
		double m_previousTime;
		
		/*! Pseudo-radom number generator seed.
		 */
		int m_nSeed;
		
		/*! Observation model to simulate measurements.
		 */
		ObservationModel *m_pObservationModel;
		
		/*! Surveillance region bounds.
		 */
		Box2D *m_pSurveillanceRegion;
		
		/*! Sensor coverage.
		 */
		Circle *m_pSensorCoverage;
};

#endif
