// -----------------------------------------------------------------------------
//! \file PipelineModuleList.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __PIPELINE_MODULE_LIST_H
#define __PIPELINE_MODULE_LIST_H

#include <string>
#include <vector>
#include "PipelineModule.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a list of pipeline modules.
// -----------------------------------------------------------------------------
class PipelineModuleList : public std::vector<PipelineModule*>
{
	public:
		PipelineModuleList();
		
		virtual ~PipelineModuleList();
		
		PipelineModule* GetModuleByIdx(size_t index);
		
		PipelineModule* GetModuleByName(std::string name);
		
		void EraseAt(size_t idx);
};

#endif
