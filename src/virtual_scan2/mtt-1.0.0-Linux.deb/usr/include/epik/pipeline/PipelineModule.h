// -----------------------------------------------------------------------------
//! \file PipelineModule.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __PIPELINE_MODULE_H
#define __PIPELINE_MODULE_H

#include <string>
#include <iostream>
#include <unordered_map>
#include <stdexcept>

// -----------------------------------------------------------------------------
//! \brief This class implements a generic pipeline module.
// -----------------------------------------------------------------------------
class PipelineModule
{
	public:
		PipelineModule(std::string name);
#if __cplusplus>=201103L
        virtual ~PipelineModule() noexcept(false);
#else
        virtual ~PipelineModule();
#endif
		virtual void Initialize() = 0;
		
		virtual void Process(double currentTime) = 0;
		
		virtual void Finalize() = 0;
		
		virtual void Rewind() = 0;
		
		std::string GetName();
		
		void SetInput(std::string name, void *input);
		
		void SetOutput(std::string name, void *output);
		
		void SetParam(std::string name, double value);
		
		void Cascade(PipelineModule *predecessor);
		
		void *GetInputByName(std::string name);
		
		void *GetOutputByName(std::string name);
		
		double GetParamByName(std::string name);
		
	protected:
		void AddInput(std::string name, void *default_input = NULL);
		
		void AddOutput(std::string name, void *default_output = NULL);
		
		void AddParam(std::string name, double default_value = 0.0);
		
	private:
		/*! Module name.
		 */
		std::string name;
		
		/*! Inputs map.
		 */
		std::unordered_map<std::string,void*> inputs;
		
		/*! Outputs map.
		 */
		std::unordered_map<std::string,void*> outputs;
		
		/*! Parameters map.
		 */
		std::unordered_map<std::string,double> params;
};

#endif

