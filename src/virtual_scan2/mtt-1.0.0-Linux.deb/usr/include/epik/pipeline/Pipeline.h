// -----------------------------------------------------------------------------
//! \file Pipeline.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __PIPELINE_H
#define __PIPELINE_H

#include <string>
#include <vector>
#include <iostream>
#include "PipelineModuleList.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a sequential pipeline.
// -----------------------------------------------------------------------------
class Pipeline : public PipelineModuleList
{
	public:
		Pipeline();
		
		virtual ~Pipeline();
		
		void AppendModule(PipelineModule *pModule);
		
		void ClearModules();
		
		void Initialize();
		
		void Process(double currentTime);
		
		void Finalize();
		
		void Rewind();
};

#endif
