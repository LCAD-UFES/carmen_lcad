// -----------------------------------------------------------------------------
//! \file AlignedInput.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __ALIGNED_INPUT_H
#define __ALIGNED_INPUT_H

#include "MathUtils.h"
#include "TrackerConfig.h"

using namespace MathUtils;

// -----------------------------------------------------------------------------
//! \brief This class aligns the input detections (plots) to the tracking frame.
// -----------------------------------------------------------------------------
class AlignedInput
{
	public:
		AlignedInput();
		
		AlignedInput(const AlignedInput &input);
		
		virtual ~AlignedInput();
		
		void SetTimeStamp(double newTimeStamp);
		
		double GetTimeStamp() const;
		
#ifdef PROPAGATE_SIZE
		/*! Measured size.
		 */
		Array1D<double> size;
#endif
		
#ifdef PROPAGATE_ORIENTATION
		/*! Measured orientation.
		 */
		double orientation;
#endif
		/*! Measurement vector.
		 */
		Array1D<double> meas;
		
		/*! Measurement covariance matrix.
		 */
		Array2D<double> measCov;
		
		/*! Detected category.
		 */
		int category;
		
	private:
		/*! Measurement time stamp.
		 */
		double timeStamp;
};

#endif
