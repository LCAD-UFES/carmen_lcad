// -----------------------------------------------------------------------------
//! \file DynamicModel.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __DYNAMIC_MODEL_H
#define __DYNAMIC_MODEL_H

#include "MathUtils.h"

// -----------------------------------------------------------------------------
//! \brief This class defines an abstract dynamic model.
// -----------------------------------------------------------------------------
class DynamicModel
{
	public:
		DynamicModel() {};

		virtual ~DynamicModel() {};

		virtual void Initialize1P(Array1D<double> &x, Array2D<double> &P) const = 0;

		virtual Array2D<double> GetStateTransitionMatrix(const Array1D<double> &x, double T) = 0;

		virtual Array2D<double> GetProcessNoiseCovarianceMatrix(const Array1D<double> &x, double T) = 0;

		virtual void GetPositionInfo(const Array1D<double> &x, Array1D<double> &pos) const = 0;

		virtual void GetPositionCovInfo(const Array2D<double> &P, Array2D<double> &posCov) const = 0;

		virtual void GetVelocityInfo(const Array1D<double> &x, Array1D<double> &vel) const = 0;

		virtual void GetVelocityCovInfo(const Array2D<double> &P, Array2D<double> &velCov) const = 0;
};

#endif
