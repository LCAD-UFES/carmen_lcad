// -----------------------------------------------------------------------------
//! \file AssignmentList.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __ASSIGNMENT_LIST_H
#define __ASSIGNMENT_LIST_H

#include <vector>
#include <string>
#include <iostream>
#include "Assignment.h"
#include "AlignedInputList.h"
#include "InnerTrackList.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a list of track-to-plot assignments.
// -----------------------------------------------------------------------------
class AssignmentList : public std::vector<Assignment>
{
	public:
		AssignmentList();
		
		AssignmentList(size_t capacity);
		
		virtual ~AssignmentList();
		
		void Populate(InnerTrackList *tracks, AlignedInputList *inputs);
		
		const Assignment& GetByIndexes(int inputIdx, int trackIdx) const;
		
		int GetNumberOfTracks() const;
		
		void SetNumberOfTracks(int nNumberOfTracks);
		
		int GetNumberOfInputs() const;
		
		void SetNumberOfInputs(int nNumberOfInputs);
		
		friend std::ostream& operator<< (std::ostream& os, const AssignmentList &list);
		
	private:
		/*! Number of aligned inputs.
		 */
		int m_nNumberOfInputs;
		
		/*! Number of tracks.
		 */
		int m_nNumberOfTracks;
		
		/*! Track-to-input assignment map.
		 */
		std::vector<int> m_assigmentMap;
};

#endif
