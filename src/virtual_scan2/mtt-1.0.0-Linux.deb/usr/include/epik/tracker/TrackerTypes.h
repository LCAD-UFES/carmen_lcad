// -----------------------------------------------------------------------------
//! \file TrackerTypes.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 23/11/2019
// -----------------------------------------------------------------------------

#ifndef __TRACKER_TYPES_H
#define __TRACKER_TYPES_H

#include <iostream>

namespace TrackerTypes
{
    
// In the synchronous mode all tracks are predicted (simultaneously) to the same observation time, i.e. all observations have
// the same time stamp, whereas in the asynchronous mode, observations may assume different time stamps.
enum enTrackerMode { SYNCHRONOUS,  ASYNCHRONOUS };

std::ostream & operator<< (std::ostream &os, const enTrackerMode &mode);

enum enFilterType { WHITE_NOISE_2DOF_MODEL_KF, RANDOM_WALK_2DOF_MODEL_KF, EKF, PF, NONE };

std::ostream & operator<< (std::ostream &os, const enFilterType &type);

enum enTrackStatus { TENTATIVE, PRELIMINARY, CONFIRMED, ZOMBIE };

std::ostream & operator<< (std::ostream &os, const enTrackStatus &status);

}

#endif
