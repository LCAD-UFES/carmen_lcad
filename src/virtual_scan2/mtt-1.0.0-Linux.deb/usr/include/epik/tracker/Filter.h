// -----------------------------------------------------------------------------
//! \file Filter.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __FILTER_H
#define __FILTER_H

#include "MathUtils.h"
#include "TrackerTypes.h"

using namespace MathUtils;

// -----------------------------------------------------------------------------
//! \brief This class defines a generic filter. This is as stateless class.
// -----------------------------------------------------------------------------
class Filter
{
	public:
		Filter() {};

		virtual ~Filter() {};

		virtual void Initialize1P(const Array1D<double> &z,
                const Array2D<double> &R,
                Array1D<double> &x,
                Array2D<double> &P) const = 0;

		virtual void Initialize2P(const Array1D<double> &z,
                const Array2D<double> &R,
                Array1D<double> &x,
                Array2D<double> &P,
                double T) const = 0;

		virtual void Prediction(const Array1D<double> &x,
                const Array2D<double> &P,
                double T,
                Array1D<double> &xPred,
                Array2D<double> &PPred) const = 0;

		virtual void Innovation(const Array1D<double> &xPred,
                const Array2D<double> &PPred,
                const Array1D<double> &z,
                const Array2D<double> &R,
                Array1D<double> &v,
                Array2D<double> &S) const = 0;

		virtual void Update(const Array1D<double> &xPred,
        		const Array2D<double> &PPred,
        		const Array1D<double> &v,
        		const Array2D<double> &S,
        		const Array2D<double> &R,
        		Array1D<double> &x,
        		Array2D<double> &P) = 0;

		virtual void FullUpdate(const Array1D<double> &z,
        		const Array2D<double> &R,
        		double T,
        		Array1D<double> &x,
        		Array2D<double> &P) = 0;

		virtual	void GetPositionInfo(const Array1D<double> &x, Array1D<double> &pos) const = 0;

		virtual	void GetPositionCovInfo(const Array2D<double> &P, Array2D<double> &posCov) const = 0;

		virtual void GetVelocityInfo(const Array1D<double> &x, Array1D<double> &vel) const = 0;

		virtual void GetVelocityCovInfo(const Array2D<double> &P, Array2D<double> &velCov) const = 0;
};

#endif
