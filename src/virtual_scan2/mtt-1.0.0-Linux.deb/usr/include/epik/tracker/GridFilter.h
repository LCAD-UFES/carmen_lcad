// -----------------------------------------------------------------------------
//! \file GridFilter.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __GRID_FILTER_H
#define __GRID_FILTER_H

#include "MathUtils.h"
#include "TrackerConfig.h"

using namespace MathUtils;
using namespace TrackerConfig;

// -----------------------------------------------------------------------------
//! \brief This class implements a grid filter.
// -----------------------------------------------------------------------------
class GridFilter
{
	public:
		GridFilter();
		
		GridFilter(const GridFilter &filter);
		
		virtual ~GridFilter();
		
		void Initialize1P(const Array1D<double> &z,
				Array1D<double> &pmf) const;
		
		void Initialize1P(int z,
				Array1D<double> &pmf) const;
		
		void Prediction(const Array1D<double> &pmf,
				Array1D<double> &pmfPred) const;
		
		void Update(const Array1D<double> &pmfPred,
				const Array1D<double> &z,
				Array1D<double> &pmf);
		
		void Update(const Array1D<double> &pmfPred,
				int z,
				Array1D<double> &pmf);
		
	private:
		/*! Transition matrix.
		 */
		Array2D<double> T;
		
		/*! Observation matrix.
		 */
		Array2D<double> B;
};

#endif
