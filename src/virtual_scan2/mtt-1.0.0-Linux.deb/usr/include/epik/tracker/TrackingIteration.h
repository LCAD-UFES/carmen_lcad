// -----------------------------------------------------------------------------
//! \file TrackingIteration.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __TRACKING_ITERATION_H
#define __TRACKING_ITERATION_H

#include "PipelineModule.h"
#include "AssignmentList.h"
#include "AssignmentSelector.h"
#include "Auction.h"
#include "InnerTrackList.h"
#include "AlignedInputList.h"

// -----------------------------------------------------------------------------
//! \brief This class implements the tracking iteration module.
// -----------------------------------------------------------------------------
class TrackingIteration : public PipelineModule
{
	public:
		TrackingIteration(std::string name);
		
		virtual ~TrackingIteration();
		
		void Initialize();
		
		void Process(double currentTime);
		
		void Finalize();
		
		void Rewind();
		
	private:
		/*! Assignment list.
		 */
		AssignmentList *m_pAssignmentList;
		
		/*! Assignment selector.
		 */
		AssignmentSelector *m_pAssignmentSelector;
		
		/*! Aligned input list.
		 */
		AlignedInputList *m_pAlignedInputList;
		
		/*! Master track list.
		 */
		InnerTrackList *m_pMasterTrackList;
};

#endif
