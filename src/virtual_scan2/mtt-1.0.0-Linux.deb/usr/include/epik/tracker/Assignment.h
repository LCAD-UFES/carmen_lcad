// -----------------------------------------------------------------------------
//! \file Assignment.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __ASSIGNMENT_H
#define __ASSIGNMENT_H

#include "AlignedInput.h"
#include "InnerTrack.h"
#include "MathUtils.h"

using namespace MathUtils;

// -----------------------------------------------------------------------------
//! \brief This class implements a track-to-plot assignment.
// -----------------------------------------------------------------------------
class Assignment
{
	public:
		Assignment();
		
		Assignment(const Assignment &assignment);
		
		virtual ~Assignment();
		
		bool CheckAssignment(const InnerTrack &track, const AlignedInput &input);
		
		/*! Track index.
		 */
		int trackIdx;
		
		/*! Aligned input index.
		 */
		int inputIdx;
		
		/*! Track-to-input assignment gain.
		 */
		double gain;
		
		/*! Track-to-input assignment likelihood.
		 */
		double likelihood;
		
		/*! Track-to-input assignment normalized distance.
		 */
		double normDistance;
		
		/*! Track predicted state vector.
		 */
		Array1D<double> predictedState;
		
		/*! Track predicted covariance matrix.
		 */
		Array2D<double> predictedCov;
		
#ifdef ESTIMATE_CATEGORY
		/*! Track predicted category p.m.f.
		 */
		Array1D<double> predictedPmf;
#endif
		/*! Input residual / innovation vector.
		 */
		Array1D<double> innovation;
		
		/*! Input residual covariance matrix.
		 */
		Array2D<double> residualCov;
};

#endif
