// -----------------------------------------------------------------------------
//! \file AssignmentSelector.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __ASSIGNMENT_SELECTOR_H
#define __ASSIGNMENT_SELECTOR_H

#include <string>
#include <list>
#include <vector>
#include "AssignmentList.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a generic assignment selector method.
// -----------------------------------------------------------------------------
class AssignmentSelector
{
	public:
		AssignmentSelector();
		
		virtual ~AssignmentSelector();
		
		virtual void Associate(AssignmentList *pAssignmentList) = 0;
		
		virtual int GetAssociatedInputIdx(int trackIdx);
		
		std::list<int> *GetNewInputs();
		
	protected:
		/*! Track-to-input assignment map.
		 */
		std::vector<int> m_track2InputMap;
		
		/*! List of new inputs.
		 */
		std::list<int> m_newInputs;
};

#endif
