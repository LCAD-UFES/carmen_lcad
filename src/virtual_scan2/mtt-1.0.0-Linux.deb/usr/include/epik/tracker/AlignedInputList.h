// -----------------------------------------------------------------------------
//! \file AlignedInputList.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __ALIGNED_INPUT_LIST_H
#define __ALIGNED_INPUT_LIST_H

#include <vector>
#include "AlignedInput.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a list of aligned inputs.
// -----------------------------------------------------------------------------
class AlignedInputList : public std::vector<AlignedInput>
{
	public:
		AlignedInputList();
		
		AlignedInputList(size_t capacity);
		
		virtual ~AlignedInputList();
		
		AlignedInput GetByIndex(int idx) { return (*this)[idx]; }
};

#endif
