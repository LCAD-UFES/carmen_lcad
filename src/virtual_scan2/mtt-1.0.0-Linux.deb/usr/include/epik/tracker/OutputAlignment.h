// -----------------------------------------------------------------------------
//! \file OutputAlignment.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __OUTPUT_ALIGNMENT_H
#define __OUTPUT_ALIGNMENT_H

#include "PipelineModule.h"
#include "InnerTrackList.h"
#include "TrackList.h"

// -----------------------------------------------------------------------------
//! \brief This class implements the tracker's output alignment module.
// -----------------------------------------------------------------------------
class OutputAlignment : public PipelineModule
{
	public:
		OutputAlignment(std::string name);
		
		virtual ~OutputAlignment();
		
		void Initialize();
		
		void Process(double currentTime);
		
		void Finalize();
		
		void Rewind();
		
	private:
		/*! Master track list.
		 */
		InnerTrackList *m_pMasterTrackList;
		
		/*! Output track list.
		 */
		TrackList *m_pOutputTrackList;
};

#endif
