// -----------------------------------------------------------------------------
//! \file TrackMaintenance.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __TRACK_MAINTENANCE_H
#define __TRACK_MAINTENANCE_H

#include "PipelineModule.h"
#include "InnerTrackList.h"
#include "Box2D.h"

// -----------------------------------------------------------------------------
//! \brief Track maintenance module.
// -----------------------------------------------------------------------------
class TrackMaintenance : public PipelineModule
{
	public:
		TrackMaintenance(std::string name);
		
		virtual ~TrackMaintenance();
		
		void Initialize();
		
		void Process(double currentTime);
		
		void Finalize();
		
		void Rewind();
		
	private:
		/*! Master track list.
		 */
		InnerTrackList *m_pMasterTrackList;
		
		/*! Surveillance region bounds.
		 */
		Box2D *m_pSurveillanceRegion;
};

#endif
