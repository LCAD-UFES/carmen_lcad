// -----------------------------------------------------------------------------
//! \file KalmanFilter.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __KALMAN_FILTER
#define __KALMAN_FILTER

#include "Filter.h"
#include "DynamicModel.h"
#include "ObservationModel.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a Kalman filter.
// -----------------------------------------------------------------------------
class KalFilter: public Filter
{
	public:
		KalFilter();
		
		KalFilter(DynamicModel *pDynamicModel, ObservationModel *pObservationModel);
		
		KalFilter(const KalFilter &kalman);
		
		virtual ~KalFilter();
		
		void Initialize1P(const Array1D<double> &z,
				const Array2D<double> &R,
				Array1D<double> &x,
				Array2D<double> &P) const;
		
		void Initialize2P(const Array1D<double> &z,
				const Array2D<double> &R,
				Array1D<double> &x,
				Array2D<double> &P,
				double T) const;
		
		void Prediction(const Array1D<double> &x,
				const Array2D<double> &P,
				double T,
				Array1D<double> &xPred,
				Array2D<double> &PPred) const;
		
		void Innovation(const Array1D<double> &xPred,
				const Array2D<double> &PPred,
				const Array1D<double> &z,
				const Array2D<double> &R,
				Array1D<double> &v,
				Array2D<double> &S) const;
		
		void Update(const Array1D<double> &xPred,
				const Array2D<double> &PPred,
				const Array1D<double> &v,
				const Array2D<double> &S,
				const Array2D<double> &R,
				Array1D<double> &x,
				Array2D<double> &P);
		
		void FullUpdate(const Array1D<double> &z,
				const Array2D<double> &R,
				double T,
				Array1D<double> &x,
				Array2D<double> &P);
		
		void SetDynamicModel(DynamicModel *pDynamicModel);
		
		DynamicModel *GetDynamicModel();
		
		void SetObservationModel(ObservationModel *pObservationModel);
		
		ObservationModel *GetObservationModel();
		
		void GetPositionInfo(const Array1D<double> &x, Array1D<double> &pos) const;
		
		void GetPositionCovInfo(const Array2D<double> &P, Array2D<double> &posCov) const;
		
		void GetVelocityInfo(const Array1D<double> &x, Array1D<double> &vel) const;
		
		void GetVelocityCovInfo(const Array2D<double> &P, Array2D<double> &velCov) const;
		
		friend std::ostream& operator<<(std::ostream &s, const KalFilter &kalman);
	
	protected:
		/*! Dynamic model.
		 */
		DynamicModel *m_pDynamicModel;
		
		/*! Observation model.
		 */
		ObservationModel *m_pObservationModel;
};

#endif
