// -----------------------------------------------------------------------------
//! \file InnerTrack.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __INNER_TRACK_H
#define __INNER_TRACK_H

#include <string>
#include "MathUtils.h"
#include "TrackerConfig.h"
#include "GridFilter.h"
#ifdef USE_IMM_FILTER
#include "IMMFilter.h"
#else
#include "KalFilter.h"
#endif

using namespace MathUtils;
using namespace TrackerConfig;

// -----------------------------------------------------------------------------
//! \brief This class defines an internal track maintained by the tracker.
// -----------------------------------------------------------------------------
class InnerTrack
{
	public:
		InnerTrack();
		
		InnerTrack(unsigned int new_var);
		
		InnerTrack(const InnerTrack &track);
		
		virtual ~InnerTrack();
		
		void SetId(unsigned int trackId);
		
		unsigned int GetId() const;
		
		void SetCreationTimeStamp(double timeStamp);
		
		double GetCreationTimeStamp() const;
		
		void SetUpdateTimeStamp(double timeStamp);
		
		double GetUpdateTimeStamp() const;
		
		void IncreaseSurvivalTime(double delta = SURVIVAL_TIME_STEP);
		
		void DecreaseSurvivalTime(double delta = SURVIVAL_TIME_STEP);
		
		void ResetSurvivalTime();
		
		double GetRemainingTime(double currentTime) const;
		
		void SetStatus(enTrackStatus status);
		
		enTrackStatus GetStatus() const;
		
		void SetAssociated(bool bAssociated);
		
		bool IsAssociated() const;
#ifdef PERSISTENT_STATUS
		void SetPersistent(bool bPersistent);
		
		bool IsPersistent() const;
#endif
		void IncreaseScans();
		
		int GetScansSinceCreation() const;
		
		int GetScansSinceCreation(double currentTime, double scanPeriod) const;
		
		void IncreaseUpdates();
		
		int GetUpdatesSinceCreation() const;
		
#ifdef USE_IMM_FILTER
		bool IsMoving() const;
#endif
		
		friend std::ostream& operator<<(std::ostream &os, const InnerTrack &track);
		
		/*! State vector.
		 */
		Array1D<double> state;
		
		/*! Covariance matrix.
		 */
		Array2D<double> stateCov;
		
		/*! Predicted state vector.
		 */
		Array1D<double> predictedState;
		
		/*! Predicted state covariance.
		 */
		Array2D<double> predictedCov;
		
		/*! Previous state vector (at last scan or frame time stamp).
		 */
		Array1D<double> previousState;
		
#ifdef SAVE_INITIAL_TRACK_STATE
		void SetInitialState(Array1D<double> initialState);
		
		Array1D<double> GetInitialState();
		
		/*! Initial state (at track creation time stamp).
		 */
		Array1D<double> initialState;
#endif
		
#ifdef PROPAGATE_SIZE
		/*! Track size in meters.
		 */
		Array1D<double> size;
#endif
		
#ifdef ESTIMATE_CATEGORY
		/*! Probability mass function describing the current belief regarding the track category.
		 */
		Array1D<double> pmf;
		
		/*! Probability mass function describing the predicted belief regarding the track category.
		 */
		Array1D<double> predictedPmf;
		
		/*! Grid filter to estimate track category.
		 */
		GridFilter gridFilter;
#endif
		
#ifdef USE_IMM_FILTER
		/*! IMM filter to estimate the track state vector.
		 */
		IMMFilter immFilter;
#else
		/*! Kalman filter to estimate track state vector.
		 */
		KalFilter kalFilter;
#endif
		
#ifndef ESTIMATE_CATEGORY
		/*! Track estimated category.
		 */
		int category;
#endif

#ifdef SPRT
		/*! Track score.
		 */
		double score;
#endif
		/*! Track trajectory length in meters.
		 */
		double trajectoryLength;
		
	private:
		/*! Unique track identification number.
		 */
		unsigned int id;
		
		/*! Track status.
		 */
		enTrackStatus status;
		
		/*! Track creation time stamp.
		 */
		double crnTimeStamp;
		
		/*! Time stamp of the last measurement update.
		 */
		double updTimeStamp;
		
		/*! Amount of time that a track could survive without measurement updates.
		 */
		double survivalTime;
		
		/*! Flag to indicate if a track was associated with a measurement of not in the last scan (or frame).
		 */
		bool associated;
		
#ifdef PERSISTENT_STATUS
		/*! Flag to indicate if a track is persistent, i.e. should be continuously extrapolated when not updated by any measurement.
		 */
		bool persistent;
#endif
		/*! Number of measurement updates since track creation.
		 */
		int updatesNumber;
		
		/*! Number of scans (or frames) since track creation.
		 */
		int scansNumber;
};

#endif
