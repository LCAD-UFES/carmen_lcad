// -----------------------------------------------------------------------------
//! \file TrackerConfig.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __TRACKER_CONFIG_H
#define __TRACKER_CONFIG_H

#include "DynamicModel.h"
#include "ObservationModel.h"
#include "Filter.h"
#include "MTTConfig.h"
#include "TrackerTypes.h"

using namespace MTTConfig;
using namespace TrackerTypes;

// Use a grid filter to estimate category from observations
//#define ESTIMATE_CATEGORY

// Use an augmented state which comprises the target size
//#define SIZE_STATE

// Use an IMM filter to propagate the track state
#define USE_IMM_FILTER

// Propagate the measurement size
#ifndef SIZE_STATE
#define PROPAGATE_SIZE
#endif

// Use a sequential probabilistic ratio test to confirm tracks (not ready yet)
//#define SPRT

// Use two observations to initialize the track state (better initial velocity)
#define USE_2P_INITIALIZATION

// Persist track which cross an entry measuring point
//#define PERSISTENT_STATUS

// Save track initial state (required by back-reckoning)
#define SAVE_INITIAL_TRACK_STATE

// If scan rate is variable, the number of scans since creation is estimated taken the current scan period
//#define FIXED_SCAN_RATE

// Continuously calculate processing frame rate
#ifndef FIXED_SCAN_RATE
#define CALCULATE_SCAN_RATE
#endif

// Reuse the tracking iteration track prediction in the Track Maintenance and Output Alignment modules
#define REUSE_TRACKING_ITERATION_PREDICTION

// Show tracker statistics (for debug)
// #define SHOW_TRACKER_STATISTICS

// Penalizes non-persistent tracks. Persistent tracks are more likely to associate with measurements
//#define PUNISH_NON_PERSISTENT

#ifdef PUNISH_NON_PERSISTENT
#undef PERSISTENT_STATUS
#define PERSISTENT_STATUS
#endif

namespace TrackerConfig
{
#ifdef SIZE_STATE
	const int INPUT_DATA_SIZE = 4;
	const int TRACK_STATE_SIZE = 6;
#else
	const int INPUT_DATA_SIZE = 2;
	const int TRACK_STATE_SIZE = 4;
#endif

	// Normalized association gate (required by the track-to-measurement assignment checking procedure)
	const double ELLIPSOIDAL_GATE_SIZE = 5.0; // []

	// Number of categories (required by the category estimation grid filter)
	const int NUMBER_OF_CATEGORIES = 64;
	
	// Probability of keeping the same category
	const double PROBABILITY_OF_KEEPING_CATEGORY = 0.99;

	// Probability of detecting truth category
	const double PROBABILITY_OF_DETECTING_TRUTH_CATEGORY = 0.6;

	// Penalizes track-to-measurement assignments with different categories
	const double CATEGORY_MISSMATCH_COST = 0.5*ELLIPSOIDAL_GATE_SIZE;

	// Penalizes non-persistent tracks (i.e. tracks without a entry measuring point)
	const double NON_PERSISTENT_PUNISHMENT_COST = 0.25*ELLIPSOIDAL_GATE_SIZE;

	// Observation model parameters
	const double XY_POSITION_NOISE_SIGMA = 0.2; // [m]
	const double XY_SIZE_NOISE_SIGMA = 0.5; // [m]

	// Dynamic model parameters
	const double XY_ACCELERATION_SIGMA = 0.1; // [m/s^2]
	const double XY_MAXIMUM_VELOCITY = 20.0; // [m/s]
	const double RESIZING_RATE_SIGMA = 0.1; // [m/s]

	// Internal bounds to limit processing burden
	const int MAX_NUMBER_OF_ASSIGNMENTS = MAX_NUMBER_OF_INPUTS*MAX_NUMBER_OF_TRACKS;

#ifndef CALCULATE_SCAN_RATE
	// Sensor scan rate
	const double SCAN_RATE = 15.0; // [Hz]

	// Sensor scan period
	const double SCAN_PERIOD = 1.0/SCAN_RATE; // [s]

	// Limit the amount of survival time (required by the track maintenance procedure)
	const double MAX_SURVIVAL_TIME = 1.0; // [s]

	// Track survival time step (required by the track maintenance procedure)
	const double SURVIVAL_TIME_STEP = 2.0*SCAN_PERIOD; // [s]

	// Avoid covariance matrix corruption (required by track prediction procedure)
	const double MIN_DELTA_TIME = SCAN_PERIOD/2.0; // [s]
#else
	// Sensor scan rate
	extern double SCAN_RATE; // [Hz]

	// Sensor scan period
	extern double SCAN_PERIOD; // [s]

	// Limit the amount of survival time (required by the track maintenance procedure)
	extern double MAX_SURVIVAL_TIME; // [s]

	// Track survival time step (required by the track maintenance procedure)
	extern double SURVIVAL_TIME_STEP; // [s]

	// Avoid covariance matrix corruption (required by track prediction procedure)
	extern double MIN_DELTA_TIME; // [s]
#endif

#ifdef SPRT
	const double SPRT_ALPHA = 0.4; // type I error (false positive) probability
	const double SPRT_BETA = 0.3; // type II error (false negative) probability
	const double SPRT_A = log(SPRT_BETA/(1.0-SPRT_ALPHA));
	const double SPRT_B = log((1.0-SPRT_BETA)/SPRT_ALPHA);
#endif

	// Tracker mode
	const enTrackerMode TRACKER_MODE = SYNCHRONOUS;
//	const enTrackerMode TRACKER_MODE = ASYNCHRONOUS;

	// M/N track confirmation parameters (required by the track maintenance procedure)
	const int M_TRACK_CONFIRMATION_RULE = 7;
	const int N_TRACK_CONFIRMATION_RULE = 5;

//	const double CONFIRMATION_EVAL_TIME = 1.5; // [s]
//	const double CONFIRMATION_HITS_PERCENT = 0.8; // [%]
//
//	const int M_TRACK_CONFIRMATION_RULE = (int) (CONFIRMATION_EVAL_TIME/SCAN_PERIOD);
//	const int N_TRACK_CONFIRMATION_RULE = (int) (CONFIRMATION_HITS_PERCENT * (double) M);
	
	// IMM filter
	const int MAX_NUMBER_OF_IMM_FILTERS = 10;

	// White noise acceleration dynamic model
	extern DynamicModel *WHITE_NOISE_ACCELERATION_MODEL;
	
	// Random walk dynamic model
	extern DynamicModel *RANDOM_WALK_DYNAMIC_MODEL;

	// 2D Cartesian observation model
	extern ObservationModel *XY_OBSERVATION_MODEL;
	
	// White noise acceleration Kalman filter
	extern Filter *MOVING_OBJECTS_KALMAN_FILTER;
	
	// Random walk Kalman filter
	extern Filter *STATIC_OBJECTS_KALMAN_FILTER;
	
	// Helper funtions
	void Initialize();

	void UpdateScanRate(double dblScanRate);

	void Finalize();
}

#endif
