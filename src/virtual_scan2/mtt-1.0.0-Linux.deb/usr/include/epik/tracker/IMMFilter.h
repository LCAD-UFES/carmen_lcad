// -----------------------------------------------------------------------------
//! \file IMMFilter.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 23/11/2019
// -----------------------------------------------------------------------------

#ifndef __IMM_FILTER_H
#define __IMM_FILTER_H

#include <vector>
#include "FilterHandler.h"

// -----------------------------------------------------------------------------
//! \brief This class defines a generic Interacting Multiple Model (IMM) filter.
// -----------------------------------------------------------------------------
class IMMFilter : public std::vector<FilterHandler>
{
	public:
		IMMFilter();
		
		IMMFilter(size_t capacity);
		
		IMMFilter(const IMMFilter &filter);
		
		virtual ~IMMFilter();
		
		void AddFilter(enFilterType type, std::string name);
		
		void RemoveFilterByName(std::string name);
		
		void RemoveAllFilters();
		
		std::string GetFastFilterName() const;
		
		void SetTransitionProbabilities(Array2D<double> tpm);
		
		void Initialize1P(const Array1D<double> &z,
			const Array2D<double> &R,
			Array1D<double> &x,
			Array2D<double> &P);
		
		void Initialize2P(const Array1D<double> &z,
			const Array2D<double> &R,
			Array1D<double> &x,
			Array2D<double> &P,
			double T);
		
		void Prediction(const Array1D<double> &x,
			const Array2D<double> &P,
			double T,
			Array1D<double> &xPred,
			Array2D<double> &PPred) const;
		
		void Innovation(const Array1D<double> &xPred,
				const Array2D<double> &PPred,
				const Array1D<double> &z,
				const Array2D<double> &R,
				Array1D<double> &v,
				Array2D<double> &S) const;

		void Update(const Array1D<double> &xPred,
        		const Array2D<double> &PPred,
        		const Array1D<double> &v,
        		const Array2D<double> &S,
        		const Array2D<double> &R,
        		Array1D<double> &x,
        		Array2D<double> &P) const;
		
		void FullUpdate(const Array1D<double> &z,
				const Array2D<double> &R,
				double T,
				Array1D<double> &x,
				Array2D<double> &P);
		
		Array1D<double> GetModeProbs() const;
		
		void GetPositionInfo(const Array1D<double> &x, Array1D<double> &pos) const;
		
		void GetPositionCovInfo(const Array2D<double> &P, Array2D<double> &posCov) const;
		
		void GetVelocityInfo(const Array1D<double> &x, Array1D<double> &vel) const;
		
		void GetVelocityCovInfo(const Array2D<double> &P, Array2D<double> &velCov) const;
		
		friend std::ostream& operator<< (std::ostream& os, const IMMFilter &filter);

	private:
		void Mixing();
		
		void Pruning();
		
		void ComputeMixingProbabilities();
		
		void UpdateModeProbabilities();
		
		void Output(Array1D<double> &x, Array2D<double> &P);
	
	protected:
		/*! Transition probability matrix.
		 */
		Array2D<double> tpm;
		
		/*! Mode probabilities.
		 */ 
		Array1D<double> modeProbs;
		
		/*! Mode mixing probabilities.
		 */
		Array2D<double> mixingProbs;
		
		/*! Fast filter index.
		 */
		size_t fastFilterIdx;
};

#endif
