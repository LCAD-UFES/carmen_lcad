// -----------------------------------------------------------------------------
//! \file Auction.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __AUCTION_H
#define __AUCTION_H

#include <vector>
#include <list>
#include "AssignmentSelector.h"
#include "AssignmentList.h"

// -----------------------------------------------------------------------------
//! \brief This class implements the Auction algorithm.
// -----------------------------------------------------------------------------
class Auction : public AssignmentSelector
{
	public:
		Auction(int nMaxNumberOfInputs, int nMaxNumberOfTracks);
		
		virtual ~Auction();
		
		void Associate(AssignmentList *pAssignmentList);
		
		int GetAssociatedInputIdx(int trackIdx);
		
		friend std::ostream& operator<< (std::ostream& os, const Auction &auction);
		
	private:
		void InitializeState(AssignmentList *pAssignmentList);
		
		/*! Number of inputs.
		 */
		int m_nNumberOfInputs;
		
		/*! Number of tracks.
		 */
		int m_nNumberOfTracks;
		
		/*! Assignment gain matrix.
		 */
		std::vector<double> m_assignmentGainMatrix;
		
		/*! Track prices.
		 */
		std::vector<double> m_trackPrices;
		
		/*! List of unassigned inputs.
		 */
		std::list<int> m_unassignedInputs;
};

#endif
