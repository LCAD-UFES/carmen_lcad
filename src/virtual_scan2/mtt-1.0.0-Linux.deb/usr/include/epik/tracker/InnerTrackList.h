// -----------------------------------------------------------------------------
//! \file InnerTrackList.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __INNER_TRACK_LIST_H
#define __INNER_TRACK_LIST_H

#include <string>
#include <vector>
#include "InnerTrack.h"

// -----------------------------------------------------------------------------
//! \brief This class implements a list of inner tracks.
// -----------------------------------------------------------------------------
class InnerTrackList : public std::vector<InnerTrack>
{
	public:
		InnerTrackList();
		
		InnerTrackList(size_t capacity);
		
		virtual ~InnerTrackList();
		
		void DeleteZombieTracks();
		
		void RemoveNonConfirmedTracks();
};

#endif
