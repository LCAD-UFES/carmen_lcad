// -----------------------------------------------------------------------------
//! \file RandomWalk2DoFModel.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/12/2019
// -----------------------------------------------------------------------------

#ifndef __RAMDOM_WALK_2DOF_MODEL_H
#define __RAMDOM_WALK_2DOF_MODEL_H

#include "DynamicModel.h"
#include "TrackerConfig.h"

// -----------------------------------------------------------------------------
//! \brief This class defines a two degrees of freedom (DoF) random walk dynamic model.
// -----------------------------------------------------------------------------
class RandomWalk2DoFModel: public DynamicModel
{
	public:
#ifdef SIZE_STATE
		RandomWalk2DoFModel(double xyAccelSigma, double xyMaxVel, double resizeSigma);
#else
		RandomWalk2DoFModel(double xyAccelSigma, double xyMaxVel);
#endif

		RandomWalk2DoFModel(const RandomWalk2DoFModel &model);

		virtual ~RandomWalk2DoFModel();

		void Initialize1P(Array1D<double> &x, Array2D<double> &P) const;

		Array2D<double> GetStateTransitionMatrix(const Array1D<double> &x, double T);

		Array2D<double> GetProcessNoiseCovarianceMatrix(const Array1D<double> &x, double T);

		void GetPositionInfo(const Array1D<double> &x, Array1D<double> &pos) const;

		void GetPositionCovInfo(const Array2D<double> &P, Array2D<double> &posCov) const;

		void GetVelocityInfo(const Array1D<double> &x, Array1D<double> &vel) const;

		void GetVelocityCovInfo(const Array2D<double> &P, Array2D<double> &velCov) const;

//		friend std::ostream& operator<<(std::ostream &s, const RandomWalk2DoFModel &model);

	private:
		/*! Initial velocity variances.
		 */
		Array1D<double> initialVelVar;

		/*! Acceleration noise power spectral density \f$\frac{m^2}{s^4}\f$ in local cartesian coordinates.
		 */
		Array1D<double> accelVar;

		/*! State transition matrix.
		 */
		Array2D<double> F;

		/*! Process noise covariance matrix.
		 */
		Array2D<double> Q;

#ifdef SIZE_STATE
		double resizeVar;
#endif
};

#endif
