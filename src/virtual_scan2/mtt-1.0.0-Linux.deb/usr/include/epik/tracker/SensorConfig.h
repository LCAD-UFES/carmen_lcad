// -----------------------------------------------------------------------------
//! \file SensorConfig.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 25/03/2020
// -----------------------------------------------------------------------------

#ifndef __SENSOR_CONFIG_H
#define __SENSOR_CONFIG_H

#include <stdlib.h>

// -----------------------------------------------------------------------------
//! \brief This class implements a sensor configuration.
// -----------------------------------------------------------------------------
class SensorConfig
{
	public:
		SensorConfig();
		
		SensorConfig(const SensorConfig &obj);
		
		virtual ~SensorConfig();
		
		void UpdateScanRate(double currentTime);
				
		/*! Sensor index.
		 */
		size_t m_sensorIdx;
		
		/*! Sensor scan rate in Hz.
		 */
		double m_scanRate;
		
		/*! Sensor scan period in seconds.
		 */
		double m_scanPeriod;
		
		/*! Sensor last scan timestamp in seconds since Unix epoch.
		 */
		double m_previousTime;
};

#endif
