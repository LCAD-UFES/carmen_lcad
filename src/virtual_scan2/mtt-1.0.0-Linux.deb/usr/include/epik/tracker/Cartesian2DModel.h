// -----------------------------------------------------------------------------
//! \file Cartesian2DModel.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __CARTESIAN_2D_MODEL_H
#define __CARTESIAN_2D_MODEL_H

#include "ObservationModel.h"
#include "TrackerConfig.h"

// -----------------------------------------------------------------------------
//! \brief This class defines a two degrees of freedom (DoF) Cartesian observation model.
// -----------------------------------------------------------------------------
class Cartesian2DModel : public ObservationModel
{
	public:
#ifdef SIZE_STATE
		Cartesian2DModel(double xyPositionNoiseSigma, double xySizeNoiseSigma);
#else
		Cartesian2DModel(double xyPositionNoiseSigma);
#endif
		Cartesian2DModel(const Cartesian2DModel &model);

		virtual ~Cartesian2DModel();

		void Initialize1P(const Array1D<double> &z,
				const Array2D<double> &R,
				Array1D<double> &x,
				Array2D<double> &P) const;

		Array2D<double> GetObservationMatrix(const Array1D<double> &xPred);

		Array2D<double> GetCovarianceMatrix(const Array1D<double> &xPred);

	private:
		/*! Observation matrix.
		 */
		Array2D<double> H;

		/*! Covariance matrix.
		 */
		Array2D<double> R;
};

#endif
