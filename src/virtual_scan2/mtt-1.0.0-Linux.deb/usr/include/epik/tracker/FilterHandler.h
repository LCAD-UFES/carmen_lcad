// -----------------------------------------------------------------------------
//! \file FilterHandler.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 23/11/2019
// -----------------------------------------------------------------------------

#ifndef __FILTER_HANDLER_H
#define __FILTER_HANDLER_H

#include "Filter.h"
#include "TrackerConfig.h"
#include "TrackerTypes.h"

using namespace TrackerConfig;
using namespace TrackerTypes;

// -----------------------------------------------------------------------------
//! \brief This class defines a filter handler.
// -----------------------------------------------------------------------------
class FilterHandler
{
	public:
		FilterHandler(enFilterType type, std::string name);
		
		FilterHandler(const FilterHandler &handler);
		
		virtual ~FilterHandler();
		
		bool operator==(const std::string &name) const { return this->name == name; }
		
		friend std::ostream& operator<<(std::ostream &os, const FilterHandler &handler);
	
	public:
		/*! Filter pointer.
		 */
		Filter *filter;
		
		/*! Filter type.
		 */
		enFilterType type;
		
		/*! Filter name.
		 */
		std::string name;
		
		/*! State vector.
		 */
		Array1D<double> state;
		
		/*! Covariance matrix.
		 */
		Array2D<double> stateCov;
		
		/*! Mixed state vector.
		 */
		Array1D<double> mixedState;
		
		/*! Mixed covariance matrix.
		 */
		Array2D<double> mixedStateCov;
		
		/** Predicted state vector.
		 */
		Array1D<double> predictedState;
		
		/** Predicted state covariance.
		 */
		Array2D<double> predictedCov;
		
		/** Innovation vector.
		 */
		Array1D<double> innovation;
		
		/** Innovation covariance.
		 */
		Array2D<double> innovationCov;
		
		/** Likelihood.
		 */ 
		double likelihood;
};

#endif
