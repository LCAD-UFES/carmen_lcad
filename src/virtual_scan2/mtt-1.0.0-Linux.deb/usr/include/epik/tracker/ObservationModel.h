// -----------------------------------------------------------------------------
//! \file ObservationModel.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __OBSERVATION_MODEL_H
#define __OBSERVATION_MODEL_H

#include "MathUtils.h"

using namespace MathUtils;

// -----------------------------------------------------------------------------
//! \brief This class defines an abstract observation model.
// -----------------------------------------------------------------------------
class ObservationModel
{
	public:
		ObservationModel() {};

		virtual ~ObservationModel() {};

		virtual void Initialize1P(const Array1D<double> &z,
				const Array2D<double> &R,
				Array1D<double> &x,
				Array2D<double> &P) const = 0;

		virtual Array2D<double> GetObservationMatrix(const Array1D<double> &xPred) = 0;

		virtual Array2D<double> GetCovarianceMatrix(const Array1D<double> &xPred) = 0;
};

#endif
