// -----------------------------------------------------------------------------
//! \file InputAlignment.h
//!
//! \author Stiven S. Dias <stivendias@gmail.com>
//! \date 01/04/2014
// -----------------------------------------------------------------------------

#ifndef __INPUT_ALIGNMENT_H
#define __INPUT_ALIGNMENT_H

#include "PipelineModule.h"
#include "PlotList.h"
#include "AlignedInputList.h"

// -----------------------------------------------------------------------------
//! \brief This class implements the tracker's input alignment module.
// -----------------------------------------------------------------------------
class InputAlignment : public PipelineModule
{
	public:
		InputAlignment(std::string name);
		
		virtual ~InputAlignment();
		
		void Initialize();
		
		void Process(double currentTime);
		
		void Finalize();
		
		void Rewind();
		
	private:
		/*! Plot list.
		 */
		PlotList *m_pPlotList;
		
		/*! Aligned input list.
		 */
		AlignedInputList *m_pAlignedInputList;
};

#endif
